from fastapi import FastAPI, UploadFile, File
import shutil
import utility
import helper
import uvicorn

app = FastAPI()

model_list = {
    1: 'cnn',
    2: 'mobile-net',
    3: 'vgg16',
    4: 'densenet',
}


@app.get("/")
def home():
    return {'status': 'Connected'}


@app.post("/")
def post(number: int, file: UploadFile = File(...)):
    if number in model_list.keys():
        labels = utility.getLabels(app, number)

        path = 'images/image.jpg'
        with open(path, 'wb') as buffer:
            shutil.copyfileobj(file.file, buffer)

        elements = helper.prediction(app, path, number)
        result = utility.getResult(elements, labels)
        result['model_name'] = model_list[number]
        return result

    else:
        return {'result': 'Wrong model number'}


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.10", port=80, reload=True, proxy_headers=True)
