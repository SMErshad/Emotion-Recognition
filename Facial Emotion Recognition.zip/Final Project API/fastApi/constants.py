CNN_DATA = '../storage/models/CNN_model_filter.h5'
CNN_MOBILE_DATA = '../storage/models/MobileNet-Classification-7emotions-CNN.h5'
DENSENET_DATA = '../storage/models/DenseNet.hdf5'
VGG16_DATA = '../storage/models/model_vgg16.h5'
