import model_loader


def getLabels(app, number):
    if number == 1:
        labels = ['Anger', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
        model_loader.cnn_initialize(app)
    elif number == 2:
        labels = ['Anger', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', "Surprise"]
        model_loader.mobile_initialize(app)
    elif number == 3:
        labels = ['Anger', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
        model_loader.cnn_initialize(app)
    elif number == 4:
        labels = ['Anger', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', "Surprise"]
        model_loader.densenet_initialize(app)
    else:
        labels = []

    return labels


def getResult(elements, labels):
    index = 0
    maxElement = elements[0]
    for i in range(0, len(elements)):
        if elements[i] > maxElement:
            maxElement = elements[i]
            index = i

    return {
        'result': {
            'label': labels[index],
            'prediction': elements[index]
        },
        'items': {
            labels[0]: elements[0],
            labels[1]: elements[1],
            labels[2]: elements[2],
            labels[3]: elements[3],
            labels[4]: elements[4],
            labels[5]: elements[5],
            labels[6]: elements[6],
        }
    }
