import constants as const
from keras.models import load_model


def cnn_initialize(app):
    app.cnn_data = load_model(const.CNN_DATA)


def mobile_initialize(app):
    app.mobile_data = load_model(const.CNN_MOBILE_DATA)


def vgg_initialize(app):
    app.vgg16_data = load_model(const.CNN_DATA)


def densenet_initialize(app):
    app.densenet_data = load_model(const.DENSENET_DATA)