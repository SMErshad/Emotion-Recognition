import numpy as np
import keras


def prediction(df, path, number):
    if number == 1:
        result = cnn(df.cnn_data, path)
    elif number == 2:
        result = mobile(df.mobile_data, path)
    elif number == 3:
        result = vgg(df.cnn_data, path)
    elif number == 4:
        result = densenet(df.densenet_data, path)
    else:
        result = [[]]

    elements = []
    for item in range(0, len(result[0])):
        elements.append(("%.17f" % result[0][item]).rstrip('0').rstrip('.'))

    return elements


def cnn(df, path):
    img = keras.utils.load_img(path, grayscale=True, target_size=(48, 48))
    x = keras.utils.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x /= 255
    return df.predict(x)


def mobile(df, path):
    img = keras.utils.load_img(path, target_size=(48, 48))
    img_tensor = keras.utils.img_to_array(img)
    x = np.expand_dims(img_tensor, axis=0)
    x /= 255
    x = np.array(x, 'float32')
    return df.predict(x)


def vgg(df, path):
    img = keras.utils.load_img(path, grayscale=True, target_size=(48, 48))
    x = keras.utils.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x /= 255
    return df.predict(x)


def densenet(df, path):
    img = keras.utils.load_img(path, target_size=(48, 48))
    img_tensor = keras.utils.img_to_array(img)
    x = np.expand_dims(img_tensor, axis=0)
    x /= 255
    return df.predict(x)
